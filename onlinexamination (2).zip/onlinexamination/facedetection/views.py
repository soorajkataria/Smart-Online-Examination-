# facedetection/views.py

from django.http import HttpResponse

def index(request):
    return HttpResponse("Hello, this is the face detection app.")
