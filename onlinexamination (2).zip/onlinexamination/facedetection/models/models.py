# facedetection/models.py

from django.db import models

from exam.models import Violation

class DetectionLog(models.Model):
    timestamp = models.DateTimeField(auto_now_add=True)
    image = models.ImageField(upload_to='detections/')
    details = models.TextField()
    Violation = models.ForeignKey(Violation,on_delete=models.CASCADE)
