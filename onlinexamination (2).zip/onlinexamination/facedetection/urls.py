# facedetection/urls.py

from django.urls import path
from . import views  # Corrected import

urlpatterns = [
    path('', views.index, name='index'),  # Adjust according to your view functions
]
