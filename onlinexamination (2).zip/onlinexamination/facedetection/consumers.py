from channels.generic.websocket import AsyncWebsocketConsumer
import cv2
import base64
import numpy as np
import json
import os
from django.conf import settings
from asgiref.sync import async_to_sync
from django.utils import timezone
import threading
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'onlinexam.settings')

django.setup()

from exam.models import Student
from exam.models import Course
from exam.models import Violation
from django.contrib.auth.models import User

def get_static_path(filename):
    if settings.STATIC_ROOT:
        return os.path.join(settings.STATIC_ROOT, 'opencv-data', filename)
    else:
        for dir in settings.STATICFILES_DIRS:
            potential_path = os.path.join(dir, 'opencv-data', filename)
            if os.path.exists(potential_path):
                return potential_path
    raise FileNotFoundError(f"{filename} not found in STATIC_ROOT or STATICFILES_DIRS")

class VideoConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        await self.accept()

    async def disconnect(self, close_code):
        pass

    async def receive(self, text_data):
        data = json.loads(text_data)
        if data.get('action') == 'init':
            self.student_id = data.get('studentId')
            self.exam_id = data.get('examId')
        else:
            b64_frame = data.get('frame')
            
            if not b64_frame:
                await self.send(text_data=json.dumps({'error': 'No frame data received'}))
                return
            
            try:
                frame = self.base64_to_frame(b64_frame)
                threading.Thread(target=self.process_and_send_frame, args=(frame,)).start()
            except Exception as e:
                await self.send(text_data=json.dumps({'error': f'Error decoding frame: {str(e)}'}))

    def process_and_send_frame(self, frame):
        processed_frame, direction, alert_message = self.process_frame(frame)
        response_frame = self.frame_to_base64(processed_frame)

        if alert_message:
            self.log_violation(self.student_id, self.exam_id, 'ALERT! Face crossed boundary')

        async_to_sync(self.send)(text_data=json.dumps({
            'frame': response_frame,
            'direction': direction,
            'alert': alert_message
        }))

    def process_frame(self, frame):
        frame = self.resize_frame(frame, scale=0.5)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        face_cascade = cv2.CascadeClassifier(get_static_path('haarcascade_frontalface_default.xml'))
        eye_cascade = cv2.CascadeClassifier(get_static_path('haarcascade_eye.xml'))

        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=4, minSize=(30, 30))
        direction, alert_message = "unknown", None
        self.draw_boundary(frame)

        if len(faces) == 0:
            cv2.putText(frame, 'Face not detected!', (50, 150), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
        else:
            for (x, y, w, h) in faces:
                if self.check_boundary(x, y, w, h):
                    alert_message = 'ALERT! Face crossed boundary'
                self.annotate_face(frame, x, y, w, h, gray, eye_cascade)

        return frame, direction, alert_message

    def resize_frame(self, frame, scale=0.5):
        width = int(frame.shape[1] * scale)
        height = int(frame.shape[0] * scale)
        return cv2.resize(frame, (width, height), interpolation=cv2.INTER_AREA)

    def base64_to_frame(self, b64data):
        img_data = base64.b64decode(b64data)
        nparr = np.frombuffer(img_data, np.uint8)
        return cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    def frame_to_base64(self, frame, quality=75):
        encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), quality]
        _, buffer = cv2.imencode('.jpg', frame, encode_param)
        return base64.b64encode(buffer).decode('utf-8')

    def draw_boundary(self, frame):
        boundary_left = 60
        boundary_right = 270 
        boundary_top = 50
        boundary_bottom = 200
        cv2.rectangle(frame, (boundary_left, boundary_top), (boundary_right, boundary_bottom), (0, 255, 0), 2)


    def check_boundary(self, x, y, w, h):
        boundary_left = 60
        boundary_right = 270
        boundary_top = 50
        boundary_bottom = 200
        return x < boundary_left or x + w > boundary_right or y < boundary_top or y + h > boundary_bottom

    def annotate_face(self, frame, x, y, w, h, gray, eye_cascade):
        cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)
        roi_gray = gray[y:y+h, x:x+w]
        eyes = eye_cascade.detectMultiScale(roi_gray)
        for (ex, ey, ew, eh) in eyes:
            cv2.rectangle(frame, (x + ex, y + ey), (x + ex + ew, y + ey + eh), (0, 255, 0), 2)

    def log_violation(self, username, course, description):

        # users = User.objects.all()
        # for user in users:
        #     print(f"Username: {user.username}, Email: {user.email}, trvdg: {student_id}")

        user = User.objects.get(username=username)
        student = Student.objects.get(user=user)
        exam = Course.objects.get(pk=course)
        Violation.objects.create(student=student, exam=exam, description=description, timestamp=timezone.now())
